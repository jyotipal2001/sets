package sets;

public class BalancedPrenthesis {
	//function to print all combination of balanced parenthesis
	public static void _printParenthesis(char str[],int pos,int n,int open,int close) {
		if(close==n) {
			for(int i=0;i<str.length;i++)
				System.out.println(str[i]);
			System.out.println();
			return;
		}
		else {
			if(open>close) {
				str[pos]='}';
				_printParenthesis(str,pos+1,n,open,close+1);
			}
			if(open<n) {
				str[pos]='{';
				_printParenthesis(str,pos+1,n,open+1,close);
			}
		}
	}
	public static void printParenthesis(char str[],int n){
		if(n>0)
			_printParenthesis(str,0,n,0,0);
		return;
	}

	public static void main(String[] args) {
		int n=3;
		char[]str=new char[2*n];
		printParenthesis(str,n);

	}

}
