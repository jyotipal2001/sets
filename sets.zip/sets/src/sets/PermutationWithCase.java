package sets;

public class PermutationWithCase {
	public static void printWithSpace(char[]str,int pos){
		if(pos==str.length) {
			for(int i=0;i<pos;i++)
				System.out.println(str[i]);
			System.out.println(" ");
				return;
			}
			if(str[pos]>='0'&&str[pos]<='9') {
				printWithSpace(str,pos+1);
				return;
			}
			str[pos]=Character.toLowerCase(str[pos]);
			printWithSpace(str,pos+1);
			str[pos]=Character.toUpperCase(str[pos]);
			printWithSpace(str,pos+1);
		}
		

	public static void main(String[] args) {
		String input="a1b2c3";
		char[]str=input.toCharArray();
		printWithSpace(str,0);
	}
	
}
