package sets;

public class PrintOnesGreaterZeroes {
	//to generate n digit
	public static void printRec(String number,int extraones,int remainingplaces){
		//if number generated base condition
		if(0==remainingplaces) {
			System.out.println(number+" ");
			return;
		}
		//append 1 at current number and reduce remaining places 1
		printRec(number+"1",extraones+1,remainingplaces-1);
		//if more ones than zeroes then append 0 to curren number
		if(0<extraones) {
			printRec(number+"0",extraones-1,remainingplaces-1);
		}
	}
	static void printNums(int n) {
		String str="";
		printRec(str,0,n);
	}

	public static void main(String[] args) {
		int n=4;
		printNums(n);

	}

}
